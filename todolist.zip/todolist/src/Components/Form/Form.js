import "./Form.css";
import { useState } from "react";

// Создаем функциональный компонент Form, который принимает пропс putTodo.
const Form = ({ putTodo }) => {
  const [value, setValue] = useState(""); // Создаем состояние для хранения текста новой задачи (value).

  // Функция, которая вызывается при отправке формы (submit).
  const handleSubmit = (e) => {
    e.preventDefault(); // Предотвращаем стандартное поведение формы (перезагрузку страницы).
    putTodo(value); // Вызываем функцию putTodo из родительского компонента, передавая ей текст задачи.
    setValue(""); // Сбрасываем значение input поля на пустую строку.
  };

  // Возвращаем JSX (разметку) для компонента Form.
  return (
    <form className="form" onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Введите текст..."
        className="input"
        value={value} // Значение input поля связано с состоянием value.
        onChange={(e) => setValue(e.target.value)} // При изменении input поля обновляем состояние value.
      />
    </form>
  );
};

export default Form;
