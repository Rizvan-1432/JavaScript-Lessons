import { useEffect, useState } from 'react';
import './App.css';
import Form from '../Form/Form';

function App() {
  const [todos, setTodos] = useState([]); // Создаем состояние для хранения списка задач (todos).
  const [allTodos, setAllTodos] = useState(0);  // Создаем состояние для общего числа задач (allTodos).
  const [allComplete, setAllComplete] = useState(0);  // Создаем состояние для общего числа завершенных задач (allComplete).

  useEffect(() => { // Используем useEffect для обновления allComplete, когда список задач todos меняется.
    setAllComplete(todos.filter((todo) => todo.done === true).length);  // Считаем количество завершенных задач в списке todos и обновляем состояние allComplete.
  }, [todos]);  // Зависимость - todos, так что useEffect запускается при изменениях в этом состоянии.

  const putTodo = (value) => {  // Функция для добавления новой задачи в список.
    if (value) {
      setTodos([...todos, { id: Date.now(), text: value, done: false }]); // Создаем новую задачу и добавляем ее в массив todos.
      setAllTodos(allTodos + 1);  // Увеличиваем общее количество задач.
    } else {
      alert("Введите текст!");
    }
  };

  // Функция для изменения статуса задачи (выполнена/не выполнена).
  const togleTodo = (id) => {
    setTodos(
      todos.map((todo) => {
        if (todo.id !== id) return todo;  
        // Меняем статус задачи с выполненной на не выполненную и наоборот.
        return {
          ...todo,
          done: !todo.done,
        };
      })
    );
  };

  // Функция для удаления задачи из списка.
  const removeTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id)); // Фильтруем задачи и удаляем ту, у которой id совпадает с переданным id.
    setAllTodos(allTodos - 1);  // Уменьшаем общее количество задач.
  };

  // Функция для очистки всего списка задач.
  const clearTodos = () => {
    // Очищаем список задач и сбрасываем общее количество задач.
    setTodos([]);
    setAllTodos(0);
  };

  return (
    <div className="App">
      <div className="wrapper">
        <div className="container">
          <h1 className="title">ToDoList</h1>
          <Form putTodo={putTodo} />  {/* Подключаем компонент Form для добавления новых задач. */}
          <ul className="todos">
            {todos.map((todo) => {  // Отображаем список задач в виде элементов списка.
              return (
                <li
                  className={todo.done ? "todo done" : "todo"}
                  key={todo.id}
                  onClick={() => togleTodo(todo.id)}
                >
                  {todo.text}
                  <img
                    src="./delete.png"
                    alt="delete"
                    className="delete"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeTodo(todo.id);
                    }}
                  />
                </li>
              );
            })}
            {/* Отображаем информацию о количестве задач и завершенных задач. */}
            <div className="info">
              <span>All todos: {allTodos}</span>
              <span>Complite: {allComplete}</span>
            </div>
            {/* Кнопка для очистки всех задач. */}
            <button className="btn" onClick={clearTodos}>
              Clear All
            </button>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
